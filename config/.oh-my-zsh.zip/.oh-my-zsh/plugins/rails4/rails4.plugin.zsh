echo "It looks like you have been using the 'rails4' plugin,"
echo "which has been deprecated in favor of a newly consolidated 'rails' plugin."
echo "You will want to modify your ~/.zshrc configuration to begin using it."
echo "Learn more at https://github.com/robbyrussell/oh-my-zsh/pull/2240"
